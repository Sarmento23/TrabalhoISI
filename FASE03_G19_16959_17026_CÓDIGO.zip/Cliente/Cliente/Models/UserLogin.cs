﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cliente.Models
{
    public class UserLogin
    {
        public User User { get; set; }
        public string Token { get; set; }
    }
}
